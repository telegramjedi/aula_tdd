Para configurar o projeto: npm install
Para executar o principal: npm run dev
Para executgar os testes: npm run test